package com.example.redback_mobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
